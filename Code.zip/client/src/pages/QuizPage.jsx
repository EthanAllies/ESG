export default function QuizdPage(){
    return(
        <div>QuizdPage</div>
    )
}