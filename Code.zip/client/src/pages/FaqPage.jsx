export default function FaqPage(){
    return(
        <div>FaqPage</div>
    )
}